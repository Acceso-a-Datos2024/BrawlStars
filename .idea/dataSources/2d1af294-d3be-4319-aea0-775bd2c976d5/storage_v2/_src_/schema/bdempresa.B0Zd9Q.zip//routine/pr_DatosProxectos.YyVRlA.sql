create
    definer = root@localhost procedure pr_DatosProxectos(IN _NumeroProxecto int, OUT _Nome varchar(100),
                                                         OUT _Lugar varchar(100), OUT _NumDepartamento int)
BEGIN
    SELECT Nome, Lugar, Num_Departamento INTO _Nome, _Lugar, _NumDepartamento FROM proxecto WHERE Numero_Proxecto = _NumeroProxecto;
END;

