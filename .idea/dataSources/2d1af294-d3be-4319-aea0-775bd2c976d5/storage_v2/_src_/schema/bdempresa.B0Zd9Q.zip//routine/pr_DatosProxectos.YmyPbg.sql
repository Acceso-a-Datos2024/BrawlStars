create
    definer = root@localhost procedure pr_DatosProxectos(IN _NumeroProxecto int, OUT _Nome varchar(100),
                                                         OUT _Lugar varchar(100), OUT _NumDepartamento int)
BEGIN
    SELECT Nome_proxecto, Lugar, Num_Departamento INTO _Nome, _Lugar, _NumDepartamento FROM proxecto WHERE Num_proxecto = _NumeroProxecto;
END;

