create
    definer = root@localhost function fn_nEmpDepart(_NombreDepartamento varchar(100)) returns int deterministic
BEGIN
    DECLARE _NumeroEmpleados INT;

    SELECT COUNT(*) INTO _NumeroEmpleados
    FROM empregado e
    JOIN departamento d ON e.Num_departamento_pertenece = d.Num_departamento
    WHERE d.Nome_departamento = _NombreDepartamento;

    RETURN _NumeroEmpleados;
END;

