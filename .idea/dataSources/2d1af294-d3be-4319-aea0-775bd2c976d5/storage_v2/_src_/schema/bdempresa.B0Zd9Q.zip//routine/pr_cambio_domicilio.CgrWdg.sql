create
    definer = root@localhost procedure pr_cambio_domicilio(IN _NSSEMPREGADO varchar(15), IN _RUA varchar(30),
                                                           IN _NUMERORUA int, IN _PISO varchar(4), IN _CP char(5),
                                                           IN _LOCALIDADE varchar(25))
BEGIN
	UPDATE empregado SET Rua = _RUA, Numero_Rua = _NUMERORUA, Piso = _PISO, CP = _CP, Localidade = _LOCALIDADE WHERE NSS = _NSSEMPREGADO;
END;

