create
    definer = root@localhost procedure pr_DepartControlaProxec(IN _NumeroMinimoProxectos int)
BEGIN
    SELECT d.Num_departamento, d.Nome_departamento, COUNT(p.Num_proxecto) AS NumeroProxectos
    FROM departamento d
    LEFT JOIN proxecto p ON d.Num_Departamento = p.Num_Departamento
    GROUP BY d.Num_departamento, d.Nome_departamento
    HAVING COUNT(p.Num_proxecto) >= _NumeroMinimoProxectos;
END;

